from .triggon import Triggon
from .trig_func import TrigFunc
from ._exceptions import InvalidArgumentError

__version__ = "0.1.0b1"

__all__ = ["Triggon", "TrigFunc", "InvalidArgumentError"]
